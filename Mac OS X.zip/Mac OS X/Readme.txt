New Mac OS X Cursors for Windows 2000/XP
------------------------------------

Install
-------
- Extract the archive.
- Right click the on an ".inf" file and click on "Install"
- Choose the cursorset in the control panel mouse applet
  They appear as "Mac OS X Aqua", "Mac OS X Aqua Swirl", 
  "Mac OS X Graphite", "Mac OS X Graphite Swirl", 
  "Mac OS X Radioactive", "Mac OS X Rainbow Swirl"



